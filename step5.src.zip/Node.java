/*  1:   */ public class Node
/*  2:   */ {
/*  3:   */   public String content;
/*  4:   */   public int type;
/*  5:   */   
/*  6:   */   public Node(String newContent, int newType)
/*  7:   */   {
/*  8:19 */     this.content = newContent;
/*  9:20 */     this.type = newType;
/* 10:   */   }
/* 11:   */   
/* 12:   */   public String toString()
/* 13:   */   {
/* 14:25 */     return this.content;
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\Adam\Downloads\step5.jar
 * Qualified Name:     Node
 * JD-Core Version:    0.7.0.1
 */