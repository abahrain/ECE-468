public enum ScopeType
{
  GLOBAL,  MAIN,  LOCAL;
}


/* Location:           C:\Users\Adam\Downloads\step5.jar
 * Qualified Name:     ScopeType
 * JD-Core Version:    0.7.0.1
 */