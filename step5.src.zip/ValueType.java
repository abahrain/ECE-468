public enum ValueType
{
  FLOAT,  STRING,  INT;
}


/* Location:           C:\Users\Adam\Downloads\step5.jar
 * Qualified Name:     ValueType
 * JD-Core Version:    0.7.0.1
 */