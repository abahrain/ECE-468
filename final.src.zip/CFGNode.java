/*  1:   */ import java.util.ArrayList;
/*  2:   */ import java.util.HashSet;
/*  3:   */ import java.util.Set;
/*  4:   */ 
/*  5:   */ public class CFGNode
/*  6:   */ {
/*  7:16 */   int type = 0;
/*  8:17 */   int index = 0;
/*  9:20 */   ArrayList<String> define = null;
/* 10:21 */   ArrayList<String> use = null;
/* 11:22 */   Set<String> livenessVar = new HashSet();
/* 12:   */   
/* 13:   */   public CFGNode(ArrayList<String> define, ArrayList<String> use, int type)
/* 14:   */   {
/* 15:25 */     this.type = type;
/* 16:26 */     this.use = use;
/* 17:27 */     this.define = define;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String liveness(CFGNode in)
/* 21:   */   {
/* 22:31 */     return this.livenessVar.toString();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String toString()
/* 26:   */   {
/* 27:37 */     return "use: " + this.use + "\ndefine: " + this.define + "\nliveness: " + this.livenessVar;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String testPre1(CFGNode in)
/* 31:   */   {
/* 32:41 */     if (in != null) {
/* 33:42 */       return "true";
/* 34:   */     }
/* 35:45 */     return "false";
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\Adam\Downloads\final.jar
 * Qualified Name:     CFGNode
 * JD-Core Version:    0.7.0.1
 */