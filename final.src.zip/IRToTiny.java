/*   1:    */ import java.io.PrintStream;
/*   2:    */ import java.util.ArrayList;
/*   3:    */ import java.util.LinkedHashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import java.util.Stack;
/*   7:    */ 
/*   8:    */ public class IRToTiny
/*   9:    */ {
/*  10:    */   private ArrayList<String> IR;
/*  11: 18 */   private String output = "";
/*  12: 19 */   private Stack<String> result = new Stack();
/*  13:    */   private int registerNumber;
/*  14:    */   private int tempNumber;
/*  15:    */   private SymbolTable table;
/*  16: 23 */   private int paramIndex = this.registerNumber + 1;
/*  17: 24 */   private int labelIndex = 0;
/*  18: 25 */   private String labelIndicator = null;
/*  19: 26 */   private int count = 0;
/*  20: 27 */   private int RPosition = 0;
/*  21: 28 */   private int TPosition = 0;
/*  22: 29 */   private ArrayList<String> holdRegister = new ArrayList();
/*  23: 30 */   protected Map<String, Map<String, String>> TR = new LinkedHashMap();
/*  24: 31 */   protected Map<String, Map<String, Node>> tableMap = new LinkedHashMap();
/*  25: 32 */   protected Map<String, Integer> linkCount = new LinkedHashMap();
/*  26: 33 */   protected Map<String, ArrayList<String>> tempMap = new LinkedHashMap();
/*  27: 34 */   protected Map<String, String> registerAllocate = new LinkedHashMap();
/*  28: 35 */   private Stack<CFGNode> CFG = new Stack();
/*  29: 36 */   private ArrayList<String> usedTemp = new ArrayList();
/*  30: 37 */   private int loopPosition = 0;
/*  31:    */   
/*  32:    */   public IRToTiny(ArrayList<String> input, SymbolTable table, Map<String, Map<String, Node>> inputMap, Map<String, ArrayList<String>> tempMap, Stack<CFGNode> CFG, int registerNumber, int tempNumber)
/*  33:    */   {
/*  34: 40 */     this.IR = input;
/*  35: 41 */     this.table = table;
/*  36: 42 */     this.registerNumber = registerNumber;
/*  37: 43 */     this.tempNumber = tempNumber;
/*  38: 44 */     this.paramIndex = (registerNumber + 1);
/*  39: 45 */     this.RPosition = this.paramIndex;
/*  40: 46 */     this.tableMap = inputMap;
/*  41: 47 */     this.tempMap = tempMap;
/*  42: 48 */     this.CFG = CFG;
/*  43: 50 */     for (int i = 0; i < registerNumber; i++) {
/*  44: 51 */       this.registerAllocate.put("r" + Integer.toString(i), null);
/*  45:    */     }
/*  46: 54 */     for (String key : this.tableMap.keySet())
/*  47:    */     {
/*  48: 55 */       Map<String, String> newTR = new LinkedHashMap();
/*  49: 56 */       for (Node each : ((Map)this.tableMap.get(key)).values()) {
/*  50: 57 */         if ((each.content.contains("$P")) && (!this.TR.containsKey(each.content)))
/*  51:    */         {
/*  52: 58 */           newTR.put(each.content, "$" + Integer.toString(Integer.parseInt(each.content.substring(2)) + this.paramIndex));
/*  53:    */           
/*  54: 60 */           this.RPosition = (Integer.parseInt(each.content.substring(2)) + this.paramIndex);
/*  55:    */         }
/*  56: 62 */         else if (each.content.contains("$L"))
/*  57:    */         {
/*  58: 63 */           newTR.put(each.content, "$" + Integer.toString(-Integer.parseInt(each.content.substring(2)) - this.labelIndex));
/*  59: 64 */           this.TPosition = (-Integer.parseInt(each.content.substring(2)) - this.labelIndex);
/*  60: 65 */           this.count += 1;
/*  61:    */         }
/*  62:    */         else
/*  63:    */         {
/*  64: 68 */           newTR.put(each.content, each.content);
/*  65:    */         }
/*  66:    */       }
/*  67: 73 */       newTR.put("$R", "$" + Integer.toString(this.RPosition + 1));
/*  68: 74 */       for (int i = 1; i <= this.tempNumber; i++)
/*  69:    */       {
/*  70: 75 */         newTR.put("$T" + Integer.toString(i), "$" + Integer.toString(this.TPosition - i));
/*  71: 76 */         this.count += 1;
/*  72:    */       }
/*  73: 78 */       for (String p : newTR.keySet()) {
/*  74: 79 */         if (p.contains("$P")) {
/*  75: 80 */           newTR.put(p, "$" + (this.RPosition - Integer.parseInt(p.substring(2)) + 1));
/*  76:    */         }
/*  77:    */       }
/*  78: 83 */       this.TR.put(key, newTR);
/*  79: 84 */       this.linkCount.put(key, Integer.valueOf(this.count));
/*  80: 85 */       this.count = 0;
/*  81: 86 */       this.TPosition = 0;
/*  82: 87 */       this.RPosition = this.paramIndex;
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String toString()
/*  87:    */   {
/*  88: 99 */     makeIR();
/*  89:100 */     for (int i = 0; i < this.result.size(); i++) {
/*  90:101 */       this.output = this.output.concat((String)this.result.get(i));
/*  91:    */     }
/*  92:103 */     return this.output;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public String makeIR()
/*  96:    */   {
/*  97:108 */     this.result.add(";IR code\n");
/*  98:109 */     IRcodeComment();
/*  99:110 */     this.result.add(";tiny code\n");
/* 100:111 */     initialGlobal();
/* 101:112 */     initailMain();
/* 102:114 */     for (this.loopPosition = 0; this.loopPosition < this.IR.size(); this.loopPosition += 1)
/* 103:    */     {
/* 104:116 */       String[] elements = ((String)this.IR.get(this.loopPosition)).split(" ");
/* 105:117 */       if (elements[0].equalsIgnoreCase("STOREI"))
/* 106:    */       {
/* 107:118 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 108:    */         {
/* 109:119 */           if ((elements[2].contains("$R")) || (elements[2].contains("$P"))) {
/* 110:120 */             this.result.add("move " + createTemp(elements[1]) + " " + (String)((Map)this.TR.get(this.labelIndicator)).get(elements[2]) + "\n");
/* 111:    */           } else {
/* 112:123 */             this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 113:    */           }
/* 114:    */         }
/* 115:127 */         else if (elements[1].contains("$"))
/* 116:    */         {
/* 117:128 */           this.result.add("move " + createTemp(elements[1]) + " " + elements[2] + "\n");
/* 118:    */         }
/* 119:130 */         else if (elements[2].contains("$"))
/* 120:    */         {
/* 121:131 */           this.result.add("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 122:    */         }
/* 123:    */         else
/* 124:    */         {
/* 125:134 */           this.result.add("move " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 126:135 */           this.result.add("move " + findRegister(elements[2]) + " " + elements[2] + "\n");
/* 127:    */         }
/* 128:    */       }
/* 129:138 */       else if (elements[0].equalsIgnoreCase("MULTI"))
/* 130:    */       {
/* 131:139 */         this.holdRegister.add(elements[3]);
/* 132:140 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 133:141 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 134:    */         {
/* 135:143 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 136:144 */           this.result.add("muli " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 137:    */         }
/* 138:147 */         else if (elements[1].contains("$"))
/* 139:    */         {
/* 140:148 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 141:149 */           this.result.add("muli " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 142:    */         }
/* 143:151 */         else if (elements[2].contains("$"))
/* 144:    */         {
/* 145:152 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 146:153 */           this.result.add("muli " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 147:    */         }
/* 148:    */         else
/* 149:    */         {
/* 150:156 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 151:157 */           this.result.add("muli " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 152:    */         }
/* 153:159 */         this.holdRegister.clear();
/* 154:    */       }
/* 155:161 */       else if (elements[0].equalsIgnoreCase("ADDI"))
/* 156:    */       {
/* 157:162 */         this.holdRegister.add(elements[3]);
/* 158:163 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 159:164 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 160:    */         {
/* 161:166 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 162:167 */           this.result.add("addi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 163:    */         }
/* 164:170 */         else if (elements[1].contains("$"))
/* 165:    */         {
/* 166:171 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 167:172 */           this.result.add("addi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 168:    */         }
/* 169:174 */         else if (elements[2].contains("$"))
/* 170:    */         {
/* 171:175 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 172:176 */           this.result.add("addi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 173:    */         }
/* 174:    */         else
/* 175:    */         {
/* 176:179 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 177:180 */           this.result.add("addi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 178:    */         }
/* 179:182 */         this.holdRegister.clear();
/* 180:    */       }
/* 181:184 */       else if (elements[0].equalsIgnoreCase("DIVI"))
/* 182:    */       {
/* 183:185 */         this.holdRegister.add(elements[3]);
/* 184:186 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 185:187 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 186:    */         {
/* 187:189 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 188:190 */           this.result.add("divi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 189:    */         }
/* 190:193 */         else if (elements[1].contains("$"))
/* 191:    */         {
/* 192:194 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 193:195 */           this.result.add("divi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 194:    */         }
/* 195:197 */         else if (elements[2].contains("$"))
/* 196:    */         {
/* 197:198 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 198:199 */           this.result.add("divi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 199:    */         }
/* 200:    */         else
/* 201:    */         {
/* 202:202 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 203:203 */           this.result.add("divi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 204:    */         }
/* 205:205 */         this.holdRegister.clear();
/* 206:    */       }
/* 207:207 */       else if (elements[0].equalsIgnoreCase("SUBI"))
/* 208:    */       {
/* 209:208 */         this.holdRegister.add(elements[3]);
/* 210:209 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 211:210 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 212:    */         {
/* 213:212 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 214:213 */           this.result.add("subi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 215:    */         }
/* 216:216 */         else if (elements[1].contains("$"))
/* 217:    */         {
/* 218:217 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 219:218 */           this.result.add("subi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 220:    */         }
/* 221:220 */         else if (elements[2].contains("$"))
/* 222:    */         {
/* 223:221 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 224:222 */           this.result.add("subi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 225:    */         }
/* 226:    */         else
/* 227:    */         {
/* 228:225 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 229:226 */           this.result.add("subi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 230:    */         }
/* 231:228 */         this.holdRegister.clear();
/* 232:    */       }
/* 233:230 */       else if (elements[0].equalsIgnoreCase("WRITEI"))
/* 234:    */       {
/* 235:231 */         if (elements[1].contains("$")) {
/* 236:232 */           this.result.add("sys writei " + createTemp(elements[1]) + "\n");
/* 237:    */         } else {
/* 238:235 */           this.result.add("sys writei " + elements[1] + "\n");
/* 239:    */         }
/* 240:    */       }
/* 241:239 */       else if (elements[0].equalsIgnoreCase("WRITES"))
/* 242:    */       {
/* 243:240 */         this.result.add("sys writes " + elements[1] + "\n");
/* 244:    */       }
/* 245:243 */       else if (elements[0].equalsIgnoreCase("READI"))
/* 246:    */       {
/* 247:244 */         if (elements[1].contains("$")) {
/* 248:245 */           this.result.add("sys readi " + createTemp(elements[1]) + "\n");
/* 249:    */         } else {
/* 250:248 */           this.result.add("sys readi " + elements[1] + "\n");
/* 251:    */         }
/* 252:    */       }
/* 253:252 */       else if (elements[0].equalsIgnoreCase("STOREF"))
/* 254:    */       {
/* 255:253 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 256:    */         {
/* 257:254 */           if ((elements[2].contains("$R")) || (elements[2].contains("$P"))) {
/* 258:255 */             this.result.add("move " + createTemp(elements[1]) + " " + (String)((Map)this.TR.get(this.labelIndicator)).get(elements[2]) + "\n");
/* 259:    */           } else {
/* 260:258 */             this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 261:    */           }
/* 262:    */         }
/* 263:261 */         else if (elements[1].contains("$"))
/* 264:    */         {
/* 265:262 */           this.result.add("move " + createTemp(elements[1]) + " " + elements[2] + "\n");
/* 266:    */         }
/* 267:264 */         else if (elements[2].contains("$"))
/* 268:    */         {
/* 269:265 */           this.result.add("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 270:    */         }
/* 271:    */         else
/* 272:    */         {
/* 273:268 */           this.result.add("move " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 274:269 */           this.result.add("move " + findRegister(elements[2]) + " " + elements[2] + "\n");
/* 275:    */         }
/* 276:    */       }
/* 277:272 */       else if (elements[0].equalsIgnoreCase("MULTF"))
/* 278:    */       {
/* 279:273 */         this.holdRegister.add(elements[3]);
/* 280:274 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 281:275 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 282:    */         {
/* 283:277 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 284:278 */           this.result.add("mulr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 285:    */         }
/* 286:281 */         else if (elements[1].contains("$"))
/* 287:    */         {
/* 288:282 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 289:283 */           this.result.add("mulr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 290:    */         }
/* 291:285 */         else if (elements[2].contains("$"))
/* 292:    */         {
/* 293:286 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 294:287 */           this.result.add("mulr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 295:    */         }
/* 296:    */         else
/* 297:    */         {
/* 298:290 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 299:291 */           this.result.add("mulr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 300:    */         }
/* 301:293 */         this.holdRegister.clear();
/* 302:    */       }
/* 303:295 */       else if (elements[0].equalsIgnoreCase("ADDF"))
/* 304:    */       {
/* 305:296 */         this.holdRegister.add(elements[3]);
/* 306:297 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 307:298 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 308:    */         {
/* 309:300 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 310:301 */           this.result.add("addr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 311:    */         }
/* 312:304 */         else if (elements[1].contains("$"))
/* 313:    */         {
/* 314:305 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 315:306 */           this.result.add("addr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 316:    */         }
/* 317:308 */         else if (elements[2].contains("$"))
/* 318:    */         {
/* 319:309 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 320:310 */           this.result.add("addr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 321:    */         }
/* 322:    */         else
/* 323:    */         {
/* 324:313 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 325:314 */           this.result.add("addr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 326:    */         }
/* 327:316 */         this.holdRegister.clear();
/* 328:    */       }
/* 329:318 */       else if (elements[0].equalsIgnoreCase("DIVF"))
/* 330:    */       {
/* 331:319 */         this.holdRegister.add(elements[3]);
/* 332:320 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 333:321 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 334:    */         {
/* 335:323 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 336:324 */           this.result.add("divr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 337:    */         }
/* 338:327 */         else if (elements[1].contains("$"))
/* 339:    */         {
/* 340:328 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 341:329 */           this.result.add("divr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 342:    */         }
/* 343:331 */         else if (elements[2].contains("$"))
/* 344:    */         {
/* 345:332 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 346:333 */           this.result.add("divr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 347:    */         }
/* 348:    */         else
/* 349:    */         {
/* 350:336 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 351:337 */           this.result.add("divr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 352:    */         }
/* 353:339 */         this.holdRegister.clear();
/* 354:    */       }
/* 355:341 */       else if (elements[0].equalsIgnoreCase("SUBF"))
/* 356:    */       {
/* 357:342 */         this.holdRegister.add(elements[3]);
/* 358:343 */         this.holdRegister.add(elements[2]);this.holdRegister.add(elements[1]);
/* 359:344 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 360:    */         {
/* 361:346 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 362:347 */           this.result.add("subr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 363:    */         }
/* 364:350 */         else if (elements[1].contains("$"))
/* 365:    */         {
/* 366:351 */           this.result.add("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 367:352 */           this.result.add("subr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 368:    */         }
/* 369:354 */         else if (elements[2].contains("$"))
/* 370:    */         {
/* 371:355 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 372:356 */           this.result.add("subr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 373:    */         }
/* 374:    */         else
/* 375:    */         {
/* 376:359 */           this.result.add("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 377:360 */           this.result.add("subr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 378:    */         }
/* 379:362 */         this.holdRegister.clear();
/* 380:    */       }
/* 381:364 */       else if (elements[0].equalsIgnoreCase("WRITEF"))
/* 382:    */       {
/* 383:365 */         if (elements[1].contains("$")) {
/* 384:366 */           this.result.add("sys writer " + createTemp(elements[1]) + " " + "\n");
/* 385:    */         } else {
/* 386:369 */           this.result.add("sys writer " + elements[1] + " " + "\n");
/* 387:    */         }
/* 388:    */       }
/* 389:373 */       else if (elements[0].equalsIgnoreCase("READF"))
/* 390:    */       {
/* 391:374 */         if (elements[1].contains("$")) {
/* 392:375 */           this.result.add("sys readr " + createTemp(elements[1]) + " " + "\n");
/* 393:    */         } else {
/* 394:378 */           this.result.add("sys readr " + elements[1] + " " + "\n");
/* 395:    */         }
/* 396:    */       }
/* 397:381 */       else if (elements[0].equalsIgnoreCase("LABEL"))
/* 398:    */       {
/* 399:382 */         spillRegister();
/* 400:383 */         this.result.add("label " + elements[1] + " " + "\n");
/* 401:384 */         if (!elements[1].contains("label")) {
/* 402:385 */           this.labelIndicator = elements[1];
/* 403:    */         }
/* 404:    */       }
/* 405:388 */       else if (elements[0].equalsIgnoreCase("JUMP"))
/* 406:    */       {
/* 407:389 */         spillRegister();
/* 408:390 */         this.result.add("jmp " + elements[1] + " " + "\n");
/* 409:    */       }
/* 410:393 */       else if (elements[0].equalsIgnoreCase("LEI"))
/* 411:    */       {
/* 412:395 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 413:    */         {
/* 414:396 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 415:397 */           spillRegister();
/* 416:398 */           this.result.add("jle " + elements[3] + "\n");
/* 417:    */         }
/* 418:400 */         else if (elements[1].contains("$"))
/* 419:    */         {
/* 420:401 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 421:402 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 422:403 */           spillRegister();
/* 423:404 */           this.result.add("jle " + elements[3] + "\n");
/* 424:    */         }
/* 425:406 */         else if (elements[2].contains("$"))
/* 426:    */         {
/* 427:407 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 428:408 */           spillRegister();
/* 429:409 */           this.result.add("jle " + elements[3] + "\n");
/* 430:    */         }
/* 431:    */         else
/* 432:    */         {
/* 433:412 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 434:413 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 435:414 */           spillRegister();
/* 436:415 */           this.result.add("jle " + elements[3] + "\n");
/* 437:    */         }
/* 438:    */       }
/* 439:420 */       else if (elements[0].equalsIgnoreCase("GEI"))
/* 440:    */       {
/* 441:422 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 442:    */         {
/* 443:423 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 444:424 */           spillRegister();
/* 445:425 */           this.result.add("jge " + elements[3] + "\n");
/* 446:    */         }
/* 447:427 */         else if (elements[1].contains("$"))
/* 448:    */         {
/* 449:428 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 450:429 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 451:430 */           spillRegister();
/* 452:431 */           this.result.add("jge " + elements[3] + "\n");
/* 453:    */         }
/* 454:433 */         else if (elements[2].contains("$"))
/* 455:    */         {
/* 456:434 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 457:435 */           spillRegister();
/* 458:436 */           this.result.add("jge " + elements[3] + "\n");
/* 459:    */         }
/* 460:    */         else
/* 461:    */         {
/* 462:439 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 463:440 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 464:441 */           spillRegister();
/* 465:442 */           this.result.add("jge " + elements[3] + "\n");
/* 466:    */         }
/* 467:    */       }
/* 468:447 */       else if (elements[0].equalsIgnoreCase("NEI"))
/* 469:    */       {
/* 470:449 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 471:    */         {
/* 472:450 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 473:451 */           spillRegister();
/* 474:452 */           this.result.add("jne " + elements[3] + "\n");
/* 475:    */         }
/* 476:454 */         else if (elements[1].contains("$"))
/* 477:    */         {
/* 478:455 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 479:456 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 480:457 */           spillRegister();
/* 481:458 */           this.result.add("jne " + elements[3] + "\n");
/* 482:    */         }
/* 483:460 */         else if (elements[2].contains("$"))
/* 484:    */         {
/* 485:461 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 486:462 */           spillRegister();
/* 487:463 */           this.result.add("jne " + elements[3] + "\n");
/* 488:    */         }
/* 489:    */         else
/* 490:    */         {
/* 491:466 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 492:467 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 493:468 */           spillRegister();
/* 494:469 */           this.result.add("jne " + elements[3] + "\n");
/* 495:    */         }
/* 496:    */       }
/* 497:474 */       else if (elements[0].equalsIgnoreCase("EQI"))
/* 498:    */       {
/* 499:476 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 500:    */         {
/* 501:477 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 502:478 */           spillRegister();
/* 503:479 */           this.result.add("jeq " + elements[3] + "\n");
/* 504:    */         }
/* 505:481 */         else if (elements[1].contains("$"))
/* 506:    */         {
/* 507:482 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 508:483 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 509:484 */           spillRegister();
/* 510:485 */           this.result.add("jeq " + elements[3] + "\n");
/* 511:    */         }
/* 512:487 */         else if (elements[2].contains("$"))
/* 513:    */         {
/* 514:488 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 515:489 */           spillRegister();
/* 516:490 */           this.result.add("jeq " + elements[3] + "\n");
/* 517:    */         }
/* 518:    */         else
/* 519:    */         {
/* 520:493 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 521:494 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 522:495 */           spillRegister();
/* 523:496 */           this.result.add("jeq " + elements[3] + "\n");
/* 524:    */         }
/* 525:    */       }
/* 526:501 */       else if (elements[0].equalsIgnoreCase("GTI"))
/* 527:    */       {
/* 528:503 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 529:    */         {
/* 530:504 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 531:505 */           spillRegister();
/* 532:506 */           this.result.add("jgt " + elements[3] + "\n");
/* 533:    */         }
/* 534:508 */         else if (elements[1].contains("$"))
/* 535:    */         {
/* 536:509 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 537:510 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 538:511 */           spillRegister();
/* 539:512 */           this.result.add("jgt " + elements[3] + "\n");
/* 540:    */         }
/* 541:514 */         else if (elements[2].contains("$"))
/* 542:    */         {
/* 543:515 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 544:516 */           spillRegister();
/* 545:517 */           this.result.add("jgt " + elements[3] + "\n");
/* 546:    */         }
/* 547:    */         else
/* 548:    */         {
/* 549:520 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 550:521 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 551:522 */           spillRegister();
/* 552:523 */           this.result.add("jgt " + elements[3] + "\n");
/* 553:    */         }
/* 554:    */       }
/* 555:528 */       else if (elements[0].equalsIgnoreCase("LTI"))
/* 556:    */       {
/* 557:530 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 558:    */         {
/* 559:531 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 560:532 */           spillRegister();
/* 561:533 */           this.result.add("jlt " + elements[3] + "\n");
/* 562:    */         }
/* 563:535 */         else if (elements[1].contains("$"))
/* 564:    */         {
/* 565:536 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 566:537 */           this.result.add("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 567:538 */           spillRegister();
/* 568:539 */           this.result.add("jlt " + elements[3] + "\n");
/* 569:    */         }
/* 570:541 */         else if (elements[2].contains("$"))
/* 571:    */         {
/* 572:542 */           this.result.add("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 573:543 */           spillRegister();
/* 574:544 */           this.result.add("jlt " + elements[3] + "\n");
/* 575:    */         }
/* 576:    */         else
/* 577:    */         {
/* 578:547 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 579:548 */           this.result.add("cmpi " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 580:549 */           spillRegister();
/* 581:550 */           this.result.add("jlt " + elements[3] + "\n");
/* 582:    */         }
/* 583:    */       }
/* 584:555 */       else if (elements[0].equalsIgnoreCase("LEF"))
/* 585:    */       {
/* 586:557 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 587:    */         {
/* 588:558 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 589:559 */           spillRegister();
/* 590:560 */           this.result.add("jle " + elements[3] + "\n");
/* 591:    */         }
/* 592:562 */         else if (elements[1].contains("$"))
/* 593:    */         {
/* 594:563 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 595:564 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 596:565 */           spillRegister();
/* 597:566 */           this.result.add("jle " + elements[3] + "\n");
/* 598:    */         }
/* 599:568 */         else if (elements[2].contains("$"))
/* 600:    */         {
/* 601:569 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 602:570 */           spillRegister();
/* 603:571 */           this.result.add("jle " + elements[3] + "\n");
/* 604:    */         }
/* 605:    */         else
/* 606:    */         {
/* 607:574 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 608:575 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 609:576 */           spillRegister();
/* 610:577 */           this.result.add("jle " + elements[3] + "\n");
/* 611:    */         }
/* 612:    */       }
/* 613:582 */       else if (elements[0].equalsIgnoreCase("GEF"))
/* 614:    */       {
/* 615:584 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 616:    */         {
/* 617:585 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 618:586 */           spillRegister();
/* 619:587 */           this.result.add("jge " + elements[3] + "\n");
/* 620:    */         }
/* 621:589 */         else if (elements[1].contains("$"))
/* 622:    */         {
/* 623:590 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 624:591 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 625:592 */           spillRegister();
/* 626:593 */           this.result.add("jge " + elements[3] + "\n");
/* 627:    */         }
/* 628:595 */         else if (elements[2].contains("$"))
/* 629:    */         {
/* 630:596 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 631:597 */           spillRegister();
/* 632:598 */           this.result.add("jge " + elements[3] + "\n");
/* 633:    */         }
/* 634:    */         else
/* 635:    */         {
/* 636:601 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 637:602 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 638:603 */           spillRegister();
/* 639:604 */           this.result.add("jge " + elements[3] + "\n");
/* 640:    */         }
/* 641:    */       }
/* 642:609 */       else if (elements[0].equalsIgnoreCase("NEF"))
/* 643:    */       {
/* 644:611 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 645:    */         {
/* 646:612 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 647:613 */           spillRegister();
/* 648:614 */           this.result.add("jne " + elements[3] + "\n");
/* 649:    */         }
/* 650:616 */         else if (elements[1].contains("$"))
/* 651:    */         {
/* 652:617 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 653:618 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 654:619 */           spillRegister();
/* 655:620 */           this.result.add("jne " + elements[3] + "\n");
/* 656:    */         }
/* 657:622 */         else if (elements[2].contains("$"))
/* 658:    */         {
/* 659:623 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 660:624 */           spillRegister();
/* 661:625 */           this.result.add("jne " + elements[3] + "\n");
/* 662:    */         }
/* 663:    */         else
/* 664:    */         {
/* 665:628 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 666:629 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 667:630 */           spillRegister();
/* 668:631 */           this.result.add("jne " + elements[3] + "\n");
/* 669:    */         }
/* 670:    */       }
/* 671:636 */       else if (elements[0].equalsIgnoreCase("EQF"))
/* 672:    */       {
/* 673:638 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 674:    */         {
/* 675:639 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 676:640 */           spillRegister();
/* 677:641 */           this.result.add("jeq " + elements[3] + "\n");
/* 678:    */         }
/* 679:643 */         else if (elements[1].contains("$"))
/* 680:    */         {
/* 681:644 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 682:645 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 683:646 */           spillRegister();
/* 684:647 */           this.result.add("jeq " + elements[3] + "\n");
/* 685:    */         }
/* 686:649 */         else if (elements[2].contains("$"))
/* 687:    */         {
/* 688:650 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 689:651 */           spillRegister();
/* 690:652 */           this.result.add("jeq " + elements[3] + "\n");
/* 691:    */         }
/* 692:    */         else
/* 693:    */         {
/* 694:655 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 695:656 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 696:657 */           spillRegister();
/* 697:658 */           this.result.add("jeq " + elements[3] + "\n");
/* 698:    */         }
/* 699:    */       }
/* 700:663 */       else if (elements[0].equalsIgnoreCase("GTF"))
/* 701:    */       {
/* 702:665 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 703:    */         {
/* 704:666 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 705:667 */           spillRegister();
/* 706:668 */           this.result.add("jgt " + elements[3] + "\n");
/* 707:    */         }
/* 708:670 */         else if (elements[1].contains("$"))
/* 709:    */         {
/* 710:671 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 711:672 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 712:673 */           spillRegister();
/* 713:674 */           this.result.add("jgt " + elements[3] + "\n");
/* 714:    */         }
/* 715:676 */         else if (elements[2].contains("$"))
/* 716:    */         {
/* 717:677 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 718:678 */           spillRegister();
/* 719:679 */           this.result.add("jgt " + elements[3] + "\n");
/* 720:    */         }
/* 721:    */         else
/* 722:    */         {
/* 723:682 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 724:683 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 725:684 */           spillRegister();
/* 726:685 */           this.result.add("jgt " + elements[3] + "\n");
/* 727:    */         }
/* 728:    */       }
/* 729:690 */       else if (elements[0].equalsIgnoreCase("LTF"))
/* 730:    */       {
/* 731:692 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 732:    */         {
/* 733:693 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 734:694 */           spillRegister();
/* 735:695 */           this.result.add("jlt " + elements[3] + "\n");
/* 736:    */         }
/* 737:697 */         else if (elements[1].contains("$"))
/* 738:    */         {
/* 739:698 */           this.result.add("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 740:699 */           this.result.add("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 741:700 */           spillRegister();
/* 742:701 */           this.result.add("jlt " + elements[3] + "\n");
/* 743:    */         }
/* 744:703 */         else if (elements[2].contains("$"))
/* 745:    */         {
/* 746:704 */           this.result.add("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 747:705 */           spillRegister();
/* 748:706 */           this.result.add("jlt " + elements[3] + "\n");
/* 749:    */         }
/* 750:    */         else
/* 751:    */         {
/* 752:709 */           this.result.add("move " + elements[2] + " " + findRegister(elements[2]) + "\n");
/* 753:710 */           this.result.add("cmpr " + elements[1] + " " + findRegister(elements[2]) + "\n");
/* 754:711 */           spillRegister();
/* 755:712 */           this.result.add("jlt " + elements[3] + "\n");
/* 756:    */         }
/* 757:    */       }
/* 758:716 */       else if (elements[0].equalsIgnoreCase("jsr"))
/* 759:    */       {
/* 760:717 */         for (int k = 0; k < this.registerNumber; k++) {
/* 761:718 */           this.result.add("push r" + Integer.toString(k) + "\n");
/* 762:    */         }
/* 763:720 */         this.result.add("jsr " + elements[1] + "\n");
/* 764:721 */         for (int k = this.registerNumber - 1; k >= 0; k--) {
/* 765:722 */           this.result.add("pop r" + Integer.toString(k) + "\n");
/* 766:    */         }
/* 767:    */       }
/* 768:725 */       else if (elements[0].equalsIgnoreCase("push"))
/* 769:    */       {
/* 770:726 */         if (elements.length == 1) {
/* 771:727 */           this.result.add("push\n");
/* 772:730 */         } else if (elements[1].contains("$")) {
/* 773:731 */           this.result.add("push " + createTemp(elements[1]) + "\n");
/* 774:    */         } else {
/* 775:734 */           this.result.add("push " + elements[1] + "\n");
/* 776:    */         }
/* 777:    */       }
/* 778:739 */       else if (elements[0].equalsIgnoreCase("pop"))
/* 779:    */       {
/* 780:740 */         if (elements.length == 1) {
/* 781:741 */           this.result.add("pop\n");
/* 782:744 */         } else if (elements[1].contains("$")) {
/* 783:745 */           this.result.add("pop " + createTemp(elements[1]) + "\n");
/* 784:    */         } else {
/* 785:748 */           this.result.add("pop " + elements[1] + "\n");
/* 786:    */         }
/* 787:    */       }
/* 788:753 */       else if (elements[0].equalsIgnoreCase("link"))
/* 789:    */       {
/* 790:754 */         this.result.add("link " + this.linkCount.get(this.labelIndicator) + "\n");
/* 791:    */       }
/* 792:757 */       else if (elements[0].equalsIgnoreCase("RET"))
/* 793:    */       {
/* 794:758 */         spillRegister();
/* 795:759 */         this.result.add("unlnk\n");
/* 796:760 */         this.result.add("ret\n");
/* 797:    */       }
/* 798:762 */       freeRegister();
/* 799:    */     }
/* 800:765 */     this.result.add("end");
/* 801:766 */     return this.result.toString();
/* 802:    */   }
/* 803:    */   
/* 804:    */   private void spillRegister()
/* 805:    */   {
/* 806:770 */     for (int k = 0; k < this.registerAllocate.size(); k++) {
/* 807:771 */       if (this.registerAllocate.get("r" + Integer.toString(k)) != null)
/* 808:    */       {
/* 809:772 */         this.result.add("move r" + Integer.toString(k) + " " + (String)((Map)this.TR.get(this.labelIndicator)).get(this.registerAllocate.get(new StringBuilder("r").append(Integer.toString(k)).toString())) + "\n");
/* 810:773 */         this.registerAllocate.put("r" + Integer.toString(k), null);
/* 811:    */       }
/* 812:    */     }
/* 813:    */   }
/* 814:    */   
/* 815:    */   public void initailMain()
/* 816:    */   {
/* 817:780 */     this.result.add("push\n");
/* 818:781 */     for (int k = 0; k < this.registerNumber; k++) {
/* 819:782 */       this.result.add("push r" + Integer.toString(k) + "\n");
/* 820:    */     }
/* 821:784 */     this.result.add("jsr main\n");
/* 822:785 */     this.result.add("sys halt\n");
/* 823:    */   }
/* 824:    */   
/* 825:    */   public void IRcodeComment()
/* 826:    */   {
/* 827:789 */     for (int i = 0; i < this.IR.size(); i++) {
/* 828:790 */       this.result.add(";" + (String)this.IR.get(i) + "\n");
/* 829:    */     }
/* 830:    */   }
/* 831:    */   
/* 832:    */   public void initialGlobal()
/* 833:    */   {
/* 834:796 */     for (Scope scope : this.table.scopeStack.subList(0, this.table.scopeStack.size())) {
/* 835:797 */       if (scope.type.equalsIgnoreCase("GLOBAL")) {
/* 836:798 */         for (String key : scope.symbolMap.keySet()) {
/* 837:799 */           if (((Symbol)scope.symbolMap.get(key)).type == ValueType.INT) {
/* 838:800 */             this.result.add("var " + key + "\n");
/* 839:802 */           } else if (((Symbol)scope.symbolMap.get(key)).type == ValueType.FLOAT) {
/* 840:803 */             this.result.add("var " + key + "\n");
/* 841:805 */           } else if (((Symbol)scope.symbolMap.get(key)).type == ValueType.STRING) {
/* 842:807 */             this.result.add("str " + key + " " + ((Symbol)scope.symbolMap.get(key)).descriptor.content + "\n");
/* 843:    */           } else {
/* 844:810 */             System.out.println("error@initialGlobal");
/* 845:    */           }
/* 846:    */         }
/* 847:    */       }
/* 848:    */     }
/* 849:    */   }
/* 850:    */   
/* 851:    */   private boolean registerFull()
/* 852:    */   {
/* 853:818 */     for (int i = 0; i < this.registerAllocate.size(); i++) {
/* 854:819 */       if (this.registerAllocate.get("r" + Integer.toString(i)) == null) {
/* 855:820 */         return false;
/* 856:    */       }
/* 857:    */     }
/* 858:823 */     return true;
/* 859:    */   }
/* 860:    */   
/* 861:    */   private void freeRegister()
/* 862:    */   {
/* 863:827 */     for (int i = 0; i < this.registerAllocate.size(); i++) {
/* 864:828 */       if ((this.registerAllocate.get("r" + Integer.toString(i)) != null) && 
/* 865:829 */         (!((CFGNode)this.CFG.get(this.loopPosition)).livenessVar.contains(this.registerAllocate.get("r" + Integer.toString(i))))) {
/* 866:833 */         this.registerAllocate.put("r" + Integer.toString(i), null);
/* 867:    */       }
/* 868:    */     }
/* 869:    */   }
/* 870:    */   
/* 871:    */   private String findRegister(String in)
/* 872:    */   {
/* 873:840 */     for (int i = 0; i < this.registerAllocate.size(); i++) {
/* 874:841 */       if (this.registerAllocate.get("r" + Integer.toString(i)) == null) {
/* 875:842 */         return "r" + Integer.toString(i);
/* 876:    */       }
/* 877:    */     }
/* 878:844 */     return null;
/* 879:    */   }
/* 880:    */   
/* 881:    */   public String createTemp(String temp)
/* 882:    */   {
/* 883:849 */     if (((Map)this.TR.get(this.labelIndicator)).containsKey(temp))
/* 884:    */     {
/* 885:851 */       if (this.registerAllocate.containsValue(temp))
/* 886:    */       {
/* 887:852 */         for (int i = 0; i < this.registerAllocate.size(); i++) {
/* 888:853 */           if ((this.registerAllocate.get("r" + Integer.toString(i)) != null) && 
/* 889:854 */             (((String)this.registerAllocate.get("r" + Integer.toString(i))).equals(temp)))
/* 890:    */           {
/* 891:855 */             if (this.usedTemp.contains(temp))
/* 892:    */             {
/* 893:856 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + "r" + Integer.toString(i) + "\n");
/* 894:857 */               this.usedTemp.remove(temp);
/* 895:    */             }
/* 896:859 */             return "r" + Integer.toString(i);
/* 897:    */           }
/* 898:    */         }
/* 899:    */       }
/* 900:    */       else
/* 901:    */       {
/* 902:864 */         if (registerFull())
/* 903:    */         {
/* 904:866 */           String tempR = null;
/* 905:867 */           if (this.holdRegister != null) {
/* 906:868 */             for (int i = 0; i < this.registerNumber; i++)
/* 907:    */             {
/* 908:869 */               tempR = "r" + Integer.toString(i);
/* 909:870 */               if (!this.holdRegister.contains(this.registerAllocate.get(tempR))) {
/* 910:    */                 break;
/* 911:    */               }
/* 912:    */             }
/* 913:    */           } else {
/* 914:885 */             tempR = "r1";
/* 915:    */           }
/* 916:888 */           if (((CFGNode)this.CFG.get(this.loopPosition)).livenessVar.contains(this.registerAllocate.get(tempR)))
/* 917:    */           {
/* 918:889 */             this.result.add("move " + tempR + " " + (String)((Map)this.TR.get(this.labelIndicator)).get(this.registerAllocate.get(tempR)) + "\n");
/* 919:890 */             this.usedTemp.add((String)this.registerAllocate.get(tempR));
/* 920:891 */             this.registerAllocate.put(tempR, temp);
/* 921:892 */             if (this.usedTemp.contains(temp))
/* 922:    */             {
/* 923:893 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + tempR + "\n");
/* 924:894 */               this.usedTemp.remove(temp);
/* 925:    */             }
/* 926:    */             else
/* 927:    */             {
/* 928:897 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + tempR + "\n");
/* 929:    */             }
/* 930:899 */             return tempR;
/* 931:    */           }
/* 932:902 */           this.registerAllocate.put(tempR, temp);
/* 933:903 */           if (this.usedTemp.contains(temp))
/* 934:    */           {
/* 935:904 */             this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + tempR + "\n");
/* 936:905 */             this.usedTemp.remove(temp);
/* 937:    */           }
/* 938:907 */           return tempR;
/* 939:    */         }
/* 940:911 */         for (int i = 0; i < this.registerAllocate.size(); i++) {
/* 941:912 */           if (this.registerAllocate.get("r" + Integer.toString(i)) == null)
/* 942:    */           {
/* 943:913 */             this.registerAllocate.put("r" + Integer.toString(i), temp);
/* 944:914 */             if (temp.contains("P")) {
/* 945:915 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + "r" + Integer.toString(i) + "\n");
/* 946:    */             }
/* 947:917 */             if (this.usedTemp.contains(temp))
/* 948:    */             {
/* 949:918 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + "r" + Integer.toString(i) + "\n");
/* 950:919 */               this.usedTemp.remove(temp);
/* 951:920 */               return "r" + Integer.toString(i);
/* 952:    */             }
/* 953:922 */             if (temp.contains("L")) {
/* 954:923 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + "r" + Integer.toString(i) + "\n");
/* 955:    */             }
/* 956:925 */             if (temp.contains("T")) {
/* 957:926 */               this.result.add("move " + (String)((Map)this.TR.get(this.labelIndicator)).get(temp) + " " + "r" + Integer.toString(i) + "\n");
/* 958:    */             }
/* 959:928 */             return "r" + Integer.toString(i);
/* 960:    */           }
/* 961:    */         }
/* 962:    */       }
/* 963:    */     }
/* 964:    */     else
/* 965:    */     {
/* 966:941 */       if (((Map)this.TR.get("GLOBAL")).containsKey(temp)) {
/* 967:942 */         return (String)((Map)this.TR.get("GLOBAL")).get(temp);
/* 968:    */       }
/* 969:946 */       System.out.println("register not enough!! " + temp);
/* 970:947 */       return null;
/* 971:    */     }
/* 972:949 */     System.out.println("register not enough!! " + temp);
/* 973:950 */     return null;
/* 974:    */   }
/* 975:    */ }


/* Location:           C:\Users\Adam\Downloads\final.jar
 * Qualified Name:     IRToTiny
 * JD-Core Version:    0.7.0.1
 */