/*   1:    */ import java.io.PrintStream;
/*   2:    */ import java.util.ArrayList;
/*   3:    */ import java.util.HashSet;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ import java.util.Stack;
/*   8:    */ 
/*   9:    */ public class Liveness
/*  10:    */ {
/*  11:    */   private ArrayList<String> IR;
/*  12:    */   private SymbolTable table;
/*  13: 22 */   protected Map<String, Map<String, Node>> tableMap = new LinkedHashMap();
/*  14: 23 */   private Map<String, Integer> labelPosition = new LinkedHashMap();
/*  15: 24 */   protected Stack<CFGNode> CFG = new Stack();
/*  16: 25 */   private Map<Integer, ArrayList<Integer>> loop = new LinkedHashMap();
/*  17: 26 */   private Map<Integer, Set<String>> loopRecord = new LinkedHashMap();
/*  18: 28 */   private Set<String> globalSet = new HashSet();
/*  19: 29 */   private String result = "";
/*  20:    */   
/*  21:    */   public Liveness(ArrayList<String> input, Map<String, Map<String, Node>> inputMap, SymbolTable table)
/*  22:    */   {
/*  23: 33 */     this.IR = input;
/*  24: 34 */     this.tableMap = inputMap;
/*  25: 35 */     this.table = table;
/*  26: 36 */     initialGlobal();
/*  27: 37 */     makeCFG();
/*  28:    */     
/*  29: 39 */     makeLiveness();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String toString()
/*  33:    */   {
/*  34: 46 */     for (int i = 0; i < this.CFG.size(); i++) {
/*  35: 47 */       this.result = this.result.concat(i + " " + (String)this.IR.get(i) + " " + ((CFGNode)this.CFG.get(i)).livenessVar + "\n");
/*  36:    */     }
/*  37: 49 */     return this.result;
/*  38:    */   }
/*  39:    */   
/*  40:    */   private void makeCFG()
/*  41:    */   {
/*  42: 54 */     for (int i = 0; i < this.IR.size(); i++)
/*  43:    */     {
/*  44: 55 */       String[] elements = ((String)this.IR.get(i)).split(" ");
/*  45: 56 */       ArrayList<String> use = new ArrayList();
/*  46: 57 */       ArrayList<String> define = new ArrayList();
/*  47: 58 */       if ((elements[0].equalsIgnoreCase("STOREI")) || (elements[0].equalsIgnoreCase("STOREF")))
/*  48:    */       {
/*  49: 59 */         if ((findVar(elements[1])) && (findVar(elements[2])))
/*  50:    */         {
/*  51: 60 */           use.add(elements[2]);
/*  52: 61 */           define.add(elements[1]);
/*  53: 62 */           CFGNode newNode = new CFGNode(define, use, 1);
/*  54: 63 */           this.CFG.add(newNode);
/*  55:    */         }
/*  56: 65 */         else if (findVar(elements[2]))
/*  57:    */         {
/*  58: 66 */           use.add(elements[2]);
/*  59: 67 */           CFGNode newNode = new CFGNode(define, use, 1);
/*  60: 68 */           this.CFG.add(newNode);
/*  61:    */         }
/*  62:    */       }
/*  63: 71 */       else if ((elements[0].equalsIgnoreCase("MULTI")) || (elements[0].equalsIgnoreCase("MULTF")))
/*  64:    */       {
/*  65: 72 */         use.add(elements[3]);
/*  66: 73 */         define.add(elements[1]);
/*  67: 74 */         define.add(elements[2]);
/*  68: 75 */         CFGNode newNode = new CFGNode(define, use, 1);
/*  69: 76 */         this.CFG.add(newNode);
/*  70:    */       }
/*  71: 78 */       else if ((elements[0].equalsIgnoreCase("ADDI")) || (elements[0].equalsIgnoreCase("ADDF")))
/*  72:    */       {
/*  73: 79 */         use.add(elements[3]);
/*  74: 80 */         define.add(elements[1]);
/*  75: 81 */         define.add(elements[2]);
/*  76: 82 */         CFGNode newNode = new CFGNode(define, use, 1);
/*  77: 83 */         this.CFG.add(newNode);
/*  78:    */       }
/*  79: 85 */       else if ((elements[0].equalsIgnoreCase("DIVI")) || (elements[0].equalsIgnoreCase("DIVF")))
/*  80:    */       {
/*  81: 86 */         use.add(elements[3]);
/*  82: 87 */         define.add(elements[1]);
/*  83: 88 */         define.add(elements[2]);
/*  84: 89 */         CFGNode newNode = new CFGNode(define, use, 1);
/*  85: 90 */         this.CFG.add(newNode);
/*  86:    */       }
/*  87: 92 */       else if ((elements[0].equalsIgnoreCase("SUBI")) || (elements[0].equalsIgnoreCase("SUBF")))
/*  88:    */       {
/*  89: 93 */         use.add(elements[3]);
/*  90: 94 */         define.add(elements[1]);
/*  91: 95 */         define.add(elements[2]);
/*  92: 96 */         CFGNode newNode = new CFGNode(define, use, 1);
/*  93: 97 */         this.CFG.add(newNode);
/*  94:    */       }
/*  95: 99 */       else if ((elements[0].equalsIgnoreCase("WRITEI")) || (elements[0].equalsIgnoreCase("WRITEF")))
/*  96:    */       {
/*  97:100 */         define.add(elements[1]);
/*  98:101 */         CFGNode newNode = new CFGNode(define, use, 1);
/*  99:102 */         this.CFG.add(newNode);
/* 100:    */       }
/* 101:105 */       else if (elements[0].equalsIgnoreCase("WRITES"))
/* 102:    */       {
/* 103:106 */         CFGNode newNode = new CFGNode(define, use, 1);
/* 104:107 */         this.CFG.add(newNode);
/* 105:    */       }
/* 106:110 */       else if ((elements[0].equalsIgnoreCase("READI")) || (elements[0].equalsIgnoreCase("READF")))
/* 107:    */       {
/* 108:111 */         use.add(elements[1]);
/* 109:112 */         CFGNode newNode = new CFGNode(define, use, 1);
/* 110:113 */         this.CFG.add(newNode);
/* 111:    */       }
/* 112:116 */       else if (elements[0].equalsIgnoreCase("LABEL"))
/* 113:    */       {
/* 114:117 */         use.add(elements[1]);
/* 115:118 */         CFGNode newNode = new CFGNode(define, use, 3);
/* 116:119 */         this.CFG.add(newNode);
/* 117:    */       }
/* 118:121 */       else if (elements[0].equalsIgnoreCase("JUMP"))
/* 119:    */       {
/* 120:122 */         use.add(elements[1]);
/* 121:123 */         CFGNode newNode = new CFGNode(define, use, 4);
/* 122:124 */         this.CFG.add(newNode);
/* 123:    */       }
/* 124:127 */       else if ((elements[0].equalsIgnoreCase("LEI")) || (elements[0].equalsIgnoreCase("LEF")))
/* 125:    */       {
/* 126:128 */         define.add(elements[1]);
/* 127:129 */         define.add(elements[2]);
/* 128:130 */         use.add(elements[3]);
/* 129:131 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 130:132 */         this.CFG.add(newNode);
/* 131:    */       }
/* 132:135 */       else if ((elements[0].equalsIgnoreCase("GEI")) || (elements[0].equalsIgnoreCase("GEF")))
/* 133:    */       {
/* 134:136 */         define.add(elements[1]);
/* 135:137 */         define.add(elements[2]);
/* 136:138 */         use.add(elements[3]);
/* 137:139 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 138:140 */         this.CFG.add(newNode);
/* 139:    */       }
/* 140:143 */       else if ((elements[0].equalsIgnoreCase("NEI")) || (elements[0].equalsIgnoreCase("NEF")))
/* 141:    */       {
/* 142:144 */         define.add(elements[1]);
/* 143:145 */         define.add(elements[2]);
/* 144:146 */         use.add(elements[3]);
/* 145:147 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 146:148 */         this.CFG.add(newNode);
/* 147:    */       }
/* 148:151 */       else if ((elements[0].equalsIgnoreCase("EQI")) || (elements[0].equalsIgnoreCase("EQF")))
/* 149:    */       {
/* 150:152 */         define.add(elements[1]);
/* 151:153 */         define.add(elements[2]);
/* 152:154 */         use.add(elements[3]);
/* 153:155 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 154:156 */         this.CFG.add(newNode);
/* 155:    */       }
/* 156:159 */       else if ((elements[0].equalsIgnoreCase("GTI")) || (elements[0].equalsIgnoreCase("GTF")))
/* 157:    */       {
/* 158:160 */         define.add(elements[1]);
/* 159:161 */         define.add(elements[2]);
/* 160:162 */         use.add(elements[3]);
/* 161:163 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 162:164 */         this.CFG.add(newNode);
/* 163:    */       }
/* 164:167 */       else if ((elements[0].equalsIgnoreCase("LTI")) || (elements[0].equalsIgnoreCase("LTF")))
/* 165:    */       {
/* 166:168 */         define.add(elements[1]);
/* 167:169 */         define.add(elements[2]);
/* 168:170 */         use.add(elements[3]);
/* 169:171 */         CFGNode newNode = new CFGNode(define, use, 2);
/* 170:172 */         this.CFG.add(newNode);
/* 171:    */       }
/* 172:175 */       else if (elements[0].equalsIgnoreCase("jsr"))
/* 173:    */       {
/* 174:176 */         use.add(elements[1]);
/* 175:177 */         CFGNode newNode = new CFGNode(define, use, 5);
/* 176:178 */         this.CFG.add(newNode);
/* 177:    */       }
/* 178:180 */       else if (elements[0].equalsIgnoreCase("push"))
/* 179:    */       {
/* 180:181 */         if (elements.length == 1)
/* 181:    */         {
/* 182:182 */           CFGNode newNode = new CFGNode(define, use, 1);
/* 183:183 */           this.CFG.add(newNode);
/* 184:    */         }
/* 185:    */         else
/* 186:    */         {
/* 187:186 */           define.add(elements[1]);
/* 188:187 */           CFGNode newNode = new CFGNode(define, use, 1);
/* 189:188 */           this.CFG.add(newNode);
/* 190:    */         }
/* 191:    */       }
/* 192:192 */       else if (elements[0].equalsIgnoreCase("pop"))
/* 193:    */       {
/* 194:193 */         if (elements.length == 1)
/* 195:    */         {
/* 196:194 */           CFGNode newNode = new CFGNode(define, use, 1);
/* 197:195 */           this.CFG.add(newNode);
/* 198:    */         }
/* 199:    */         else
/* 200:    */         {
/* 201:198 */           use.add(elements[1]);
/* 202:199 */           CFGNode newNode = new CFGNode(define, use, 1);
/* 203:200 */           this.CFG.add(newNode);
/* 204:    */         }
/* 205:    */       }
/* 206:204 */       else if (elements[0].equalsIgnoreCase("link"))
/* 207:    */       {
/* 208:205 */         CFGNode newNode = new CFGNode(define, use, 6);
/* 209:206 */         this.CFG.add(newNode);
/* 210:    */       }
/* 211:209 */       else if (elements[0].equalsIgnoreCase("RET"))
/* 212:    */       {
/* 213:210 */         define.add("$R");
/* 214:211 */         CFGNode newNode = new CFGNode(define, use, 7);
/* 215:212 */         this.CFG.add(newNode);
/* 216:    */       }
/* 217:    */     }
/* 218:216 */     linkCFG();
/* 219:    */   }
/* 220:    */   
/* 221:    */   private void linkCFG()
/* 222:    */   {
/* 223:220 */     for (int i = this.CFG.size() - 1; i >= 0; i--) {
/* 224:221 */       if (((CFGNode)this.CFG.elementAt(i)).type == 3) {
/* 225:222 */         this.labelPosition.put((String)((CFGNode)this.CFG.elementAt(i)).use.get(0), Integer.valueOf(i));
/* 226:    */       }
/* 227:    */     }
/* 228:225 */     for (int i = 0; i < this.CFG.size(); i++) {
/* 229:226 */       if ((((CFGNode)this.CFG.elementAt(i)).type == 2) || (((CFGNode)this.CFG.elementAt(i)).type == 4)) {
/* 230:227 */         if (i < ((Integer)this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0))).intValue())
/* 231:    */         {
/* 232:228 */           if (this.loop.containsKey(this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0))))
/* 233:    */           {
/* 234:229 */             ((ArrayList)this.loop.get(this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0)))).add(Integer.valueOf(i));
/* 235:    */           }
/* 236:    */           else
/* 237:    */           {
/* 238:232 */             ArrayList<Integer> temp = new ArrayList();
/* 239:233 */             temp.add(Integer.valueOf(i));
/* 240:234 */             this.loop.put((Integer)this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0)), temp);
/* 241:    */           }
/* 242:    */         }
/* 243:238 */         else if (this.loop.containsKey(this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0))))
/* 244:    */         {
/* 245:239 */           ((ArrayList)this.loop.get(this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0)))).add(Integer.valueOf(i));
/* 246:    */         }
/* 247:    */         else
/* 248:    */         {
/* 249:242 */           ArrayList<Integer> temp = new ArrayList();
/* 250:243 */           temp.add(Integer.valueOf(i));
/* 251:244 */           this.loop.put((Integer)this.labelPosition.get(((CFGNode)this.CFG.elementAt(i)).use.get(0)), temp);
/* 252:    */         }
/* 253:    */       }
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   private boolean findVar(String var)
/* 258:    */   {
/* 259:253 */     return (((Map)this.tableMap.get("GLOBAL")).containsKey(var)) || (var.contains("$"));
/* 260:    */   }
/* 261:    */   
/* 262:    */   private void initialGlobal()
/* 263:    */   {
/* 264:258 */     for (Scope scope : this.table.scopeStack.subList(0, this.table.scopeStack.size())) {
/* 265:259 */       if (scope.type.equalsIgnoreCase("GLOBAL")) {
/* 266:260 */         for (String key : scope.symbolMap.keySet()) {
/* 267:261 */           if (((Symbol)scope.symbolMap.get(key)).type == ValueType.INT) {
/* 268:262 */             this.globalSet.add(key);
/* 269:265 */           } else if (((Symbol)scope.symbolMap.get(key)).type == ValueType.FLOAT) {
/* 270:266 */             this.globalSet.add(key);
/* 271:269 */           } else if (((Symbol)scope.symbolMap.get(key)).type != ValueType.STRING) {
/* 272:274 */             System.out.println("error@initialGlobal");
/* 273:    */           }
/* 274:    */         }
/* 275:    */       }
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   private boolean containsAll(Set<String> in1, Set<String> in2)
/* 280:    */   {
/* 281:282 */     if (in2.isEmpty())
/* 282:    */     {
/* 283:283 */       if (in1.isEmpty()) {
/* 284:284 */         return true;
/* 285:    */       }
/* 286:287 */       return false;
/* 287:    */     }
/* 288:291 */     return in1.containsAll(in2);
/* 289:    */   }
/* 290:    */   
/* 291:    */   private void makeLiveness()
/* 292:    */   {
/* 293:297 */     int allTheSame = 0;
/* 294:298 */     for (int i = this.CFG.size() - 1; (i >= 0) && (allTheSame == 0); i--)
/* 295:    */     {
/* 296:299 */       this.loopRecord.put(Integer.valueOf(i), new HashSet(((CFGNode)this.CFG.get(i)).livenessVar));
/* 297:300 */       if (i == this.CFG.size() - 1)
/* 298:    */       {
/* 299:301 */         ((CFGNode)this.CFG.get(i)).livenessVar.addAll(this.globalSet);
/* 300:    */       }
/* 301:304 */       else if (this.loop.containsKey(Integer.valueOf(i)))
/* 302:    */       {
/* 303:305 */         for (int j = 0; j < ((ArrayList)this.loop.get(Integer.valueOf(i))).size(); j++)
/* 304:    */         {
/* 305:306 */           ((CFGNode)this.CFG.get(i)).livenessVar.addAll(((CFGNode)this.CFG.get(i + 1)).livenessVar);
/* 306:307 */           ((CFGNode)this.CFG.get(i)).livenessVar.removeAll(((CFGNode)this.CFG.get(i + 1)).use);
/* 307:308 */           ((CFGNode)this.CFG.get(i)).livenessVar.addAll(((CFGNode)this.CFG.get(i + 1)).define);
/* 308:309 */           ((CFGNode)this.CFG.get(((Integer)((ArrayList)this.loop.get(Integer.valueOf(i))).get(j)).intValue())).livenessVar.addAll(((CFGNode)this.CFG.get(i)).livenessVar);
/* 309:310 */           ((CFGNode)this.CFG.get(((Integer)((ArrayList)this.loop.get(Integer.valueOf(i))).get(j)).intValue())).livenessVar.removeAll(((CFGNode)this.CFG.get(i)).use);
/* 310:311 */           ((CFGNode)this.CFG.get(((Integer)((ArrayList)this.loop.get(Integer.valueOf(i))).get(j)).intValue())).livenessVar.addAll(((CFGNode)this.CFG.get(i)).define);
/* 311:    */         }
/* 312:    */       }
/* 313:315 */       else if (((CFGNode)this.CFG.get(i)).type == 6)
/* 314:    */       {
/* 315:316 */         ((CFGNode)this.CFG.get(i)).livenessVar.addAll(this.globalSet);
/* 316:    */       }
/* 317:    */       else
/* 318:    */       {
/* 319:319 */         ((CFGNode)this.CFG.get(i)).livenessVar.addAll(((CFGNode)this.CFG.get(i + 1)).livenessVar);
/* 320:320 */         ((CFGNode)this.CFG.get(i)).livenessVar.removeAll(((CFGNode)this.CFG.get(i + 1)).use);
/* 321:321 */         ((CFGNode)this.CFG.get(i)).livenessVar.addAll(((CFGNode)this.CFG.get(i + 1)).define);
/* 322:    */       }
/* 323:327 */       if (i == 0) {
/* 324:328 */         for (int j = this.CFG.size() - 1; j >= 0; j--) {
/* 325:329 */           if (containsAll((Set)this.loopRecord.get(Integer.valueOf(j)), ((CFGNode)this.CFG.get(j)).livenessVar))
/* 326:    */           {
/* 327:330 */             allTheSame = 1;
/* 328:    */           }
/* 329:    */           else
/* 330:    */           {
/* 331:333 */             allTheSame = 0;
/* 332:334 */             i = this.CFG.size();
/* 333:335 */             break;
/* 334:    */           }
/* 335:    */         }
/* 336:    */       }
/* 337:    */     }
/* 338:    */   }
/* 339:    */ }


/* Location:           C:\Users\Adam\Downloads\final.jar
 * Qualified Name:     Liveness
 * JD-Core Version:    0.7.0.1
 */