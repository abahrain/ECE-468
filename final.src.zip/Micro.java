/*   1:    */ import java.io.IOException;
/*   2:    */ import java.io.PrintStream;
/*   3:    */ import org.antlr.v4.runtime.ANTLRFileStream;
/*   4:    */ import org.antlr.v4.runtime.CommonTokenStream;
/*   5:    */ import org.antlr.v4.runtime.TokenStream;
/*   6:    */ import org.antlr.v4.runtime.tree.ParseTree;
/*   7:    */ import org.antlr.v4.runtime.tree.ParseTreeWalker;
/*   8:    */ 
/*   9:    */ public class Micro
/*  10:    */ {
/*  11:    */   public static void main(String[] args)
/*  12:    */   {
/*  13:    */     try
/*  14:    */     {
/*  15: 25 */       ANTLRFileStream reader = new ANTLRFileStream(args[0]);
/*  16: 26 */       MicroLexer lexer = new MicroLexer(reader);
/*  17: 27 */       TokenStream tokens = new CommonTokenStream(lexer);
/*  18:    */       
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60: 70 */       MicroParser parser = new MicroParser(tokens);
/*  61: 71 */       parser.setErrorHandler(new MyErrorStrategy());
/*  62: 72 */       ParseTree tree = parser.program();
/*  63:    */       
/*  64: 74 */       ParseTreeWalker walker = new ParseTreeWalker();
/*  65: 75 */       ExtractMicroBaseListener extractor = new ExtractMicroBaseListener(parser);
/*  66: 76 */       walker.walk(extractor, tree);
/*  67: 77 */       EvalMicroBaseVisitor visitor = new EvalMicroBaseVisitor(extractor.table, extractor.functionMap);
/*  68: 78 */       visitor.visit(tree);
/*  69:    */       
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80: 90 */       Liveness CFG = new Liveness(visitor.outputList, visitor.tableMap, extractor.table);
/*  81:    */       
/*  82: 92 */       IRToTiny translator = new IRToTiny(visitor.outputList, extractor.table, visitor.tableMap, visitor.tempMap, CFG.CFG, 4, visitor.finalTempIndex);
/*  83: 93 */       System.out.println(translator);
/*  84:    */     }
/*  85:    */     catch (IOException e)
/*  86:    */     {
/*  87: 96 */       System.out.println("file not found");
/*  88:    */     }
/*  89:    */     catch (ArrayIndexOutOfBoundsException e)
/*  90:    */     {
/*  91: 98 */       System.out.println("You didn't include the argument");
/*  92:    */     }
/*  93:    */     catch (IllegalMonitorStateException e)
/*  94:    */     {
/*  95:100 */       System.out.println("Not accepted");
/*  96:    */     }
/*  97:    */     catch (IllegalArgumentException e)
/*  98:    */     {
/*  99:102 */       System.out.println(e.getMessage());
/* 100:    */     }
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\Adam\Downloads\final.jar
 * Qualified Name:     Micro
 * JD-Core Version:    0.7.0.1
 */