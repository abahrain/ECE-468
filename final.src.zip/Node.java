/*  1:   */ public class Node
/*  2:   */ {
/*  3:   */   public String content;
/*  4:   */   public int type;
/*  5:   */   public String value;
/*  6:   */   
/*  7:   */   public Node(String newContent, int newType)
/*  8:   */   {
/*  9:23 */     this.content = newContent;
/* 10:24 */     this.type = newType;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public String toString()
/* 14:   */   {
/* 15:29 */     return this.content;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void addValue(String value)
/* 19:   */   {
/* 20:33 */     this.value = value;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\Adam\Downloads\final.jar
 * Qualified Name:     Node
 * JD-Core Version:    0.7.0.1
 */