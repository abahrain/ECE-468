/*   1:    */ import java.io.PrintStream;
/*   2:    */ import java.util.ArrayList;
/*   3:    */ import java.util.LinkedHashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Stack;
/*   6:    */ 
/*   7:    */ public class IRToTiny
/*   8:    */ {
/*   9:    */   private ArrayList<String> IR;
/*  10: 17 */   private String result = "";
/*  11:    */   private int registerNumber;
/*  12:    */   private SymbolTable table;
/*  13: 20 */   private int paramIndex = this.registerNumber + 1;
/*  14: 21 */   private int labelIndex = 0;
/*  15: 22 */   private String labelIndicator = null;
/*  16: 23 */   private int count = 0;
/*  17: 24 */   private int RPosition = 0;
/*  18: 25 */   protected Map<String, Map<String, String>> TR = new LinkedHashMap();
/*  19: 26 */   protected Map<String, Map<String, Node>> tableMap = new LinkedHashMap();
/*  20: 27 */   protected Map<String, Integer> linkCount = new LinkedHashMap();
/*  21: 28 */   protected Map<String, ArrayList<String>> tempMap = new LinkedHashMap();
/*  22:    */   
/*  23:    */   public IRToTiny(ArrayList<String> input, SymbolTable table, Map<String, Map<String, Node>> inputMap, Map<String, ArrayList<String>> tempMap, int registerNumber)
/*  24:    */   {
/*  25: 31 */     this.IR = input;
/*  26: 32 */     this.table = table;
/*  27: 33 */     this.registerNumber = registerNumber;
/*  28: 34 */     this.paramIndex = (registerNumber + 1);
/*  29: 35 */     this.RPosition = this.paramIndex;
/*  30: 36 */     this.tableMap = inputMap;
/*  31: 37 */     this.tempMap = tempMap;
/*  32: 39 */     for (String key : this.tableMap.keySet())
/*  33:    */     {
/*  34: 40 */       Map<String, String> newTR = new LinkedHashMap();
/*  35: 41 */       for (int i = 1; i <= registerNumber; i++) {
/*  36: 42 */         newTR.put("$T" + Integer.toString(i), "r" + Integer.toString(i - 1));
/*  37:    */       }
/*  38: 44 */       for (Node each : ((Map)this.tableMap.get(key)).values())
/*  39:    */       {
/*  40: 45 */         if ((each.content.contains("$P")) && (!this.TR.containsKey(each.content)))
/*  41:    */         {
/*  42: 46 */           newTR.put(each.content, "$" + Integer.toString(Integer.parseInt(each.content.substring(2)) + this.paramIndex));
/*  43:    */           
/*  44: 48 */           this.RPosition = (Integer.parseInt(each.content.substring(2)) + this.paramIndex + 1);
/*  45:    */         }
/*  46: 50 */         else if (each.content.contains("$L"))
/*  47:    */         {
/*  48: 51 */           newTR.put(each.content, "$" + Integer.toString(-Integer.parseInt(each.content.substring(2)) - this.labelIndex));
/*  49: 52 */           this.count += 1;
/*  50:    */         }
/*  51: 54 */         newTR.put("$R", "$" + Integer.toString(this.RPosition));
/*  52: 55 */         this.TR.put(key, newTR);
/*  53:    */       }
/*  54: 57 */       this.linkCount.put(key, Integer.valueOf(this.count));
/*  55: 58 */       this.count = 0;
/*  56: 59 */       this.RPosition = this.paramIndex;
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String toString()
/*  61:    */   {
/*  62: 67 */     this.result = this.result.concat(";IR code\n");
/*  63: 68 */     IRcodeComment();
/*  64: 69 */     this.result = this.result.concat(";tiny code\n");
/*  65: 70 */     initialGlobal();
/*  66: 71 */     initailMain();
/*  67: 73 */     for (int i = 0; i < this.IR.size(); i++)
/*  68:    */     {
/*  69: 74 */       String[] elements = ((String)this.IR.get(i)).split(" ");
/*  70: 75 */       if (elements[0].equalsIgnoreCase("STOREI"))
/*  71:    */       {
/*  72: 76 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/*  73:    */         {
/*  74: 77 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/*  75:    */         }
/*  76: 79 */         else if (elements[1].contains("$"))
/*  77:    */         {
/*  78: 80 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + elements[2] + "\n");
/*  79:    */         }
/*  80: 82 */         else if (elements[2].contains("$"))
/*  81:    */         {
/*  82: 83 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/*  83:    */         }
/*  84:    */         else
/*  85:    */         {
/*  86: 86 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/*  87: 87 */           this.result = this.result.concat("move " + createTemp(elements[2]) + " " + elements[2] + "\n");
/*  88:    */         }
/*  89:    */       }
/*  90: 90 */       else if (elements[0].equalsIgnoreCase("MULTI"))
/*  91:    */       {
/*  92: 91 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/*  93:    */         {
/*  94: 92 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/*  95: 93 */           this.result = this.result.concat("muli " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/*  96:    */         }
/*  97: 95 */         else if (elements[1].contains("$"))
/*  98:    */         {
/*  99: 96 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 100: 97 */           this.result = this.result.concat("muli " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 101:    */         }
/* 102: 99 */         else if (elements[2].contains("$"))
/* 103:    */         {
/* 104:100 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 105:101 */           this.result = this.result.concat("muli " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 106:    */         }
/* 107:    */         else
/* 108:    */         {
/* 109:104 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 110:105 */           this.result = this.result.concat("muli " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 111:    */         }
/* 112:    */       }
/* 113:108 */       else if (elements[0].equalsIgnoreCase("ADDI"))
/* 114:    */       {
/* 115:109 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 116:    */         {
/* 117:110 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 118:111 */           this.result = this.result.concat("addi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 119:    */         }
/* 120:113 */         else if (elements[1].contains("$"))
/* 121:    */         {
/* 122:114 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 123:115 */           this.result = this.result.concat("addi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 124:    */         }
/* 125:117 */         else if (elements[2].contains("$"))
/* 126:    */         {
/* 127:118 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 128:119 */           this.result = this.result.concat("addi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 129:    */         }
/* 130:    */         else
/* 131:    */         {
/* 132:122 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 133:123 */           this.result = this.result.concat("addi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 134:    */         }
/* 135:    */       }
/* 136:126 */       else if (elements[0].equalsIgnoreCase("DIVI"))
/* 137:    */       {
/* 138:127 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 139:    */         {
/* 140:128 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 141:129 */           this.result = this.result.concat("divi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 142:    */         }
/* 143:131 */         else if (elements[1].contains("$"))
/* 144:    */         {
/* 145:132 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 146:133 */           this.result = this.result.concat("divi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 147:    */         }
/* 148:135 */         else if (elements[2].contains("$"))
/* 149:    */         {
/* 150:136 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 151:137 */           this.result = this.result.concat("divi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 152:    */         }
/* 153:    */         else
/* 154:    */         {
/* 155:140 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 156:141 */           this.result = this.result.concat("divi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 157:    */         }
/* 158:    */       }
/* 159:144 */       else if (elements[0].equalsIgnoreCase("SUBI"))
/* 160:    */       {
/* 161:145 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 162:    */         {
/* 163:146 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 164:147 */           this.result = this.result.concat("subi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 165:    */         }
/* 166:149 */         else if (elements[1].contains("$"))
/* 167:    */         {
/* 168:150 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 169:151 */           this.result = this.result.concat("subi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 170:    */         }
/* 171:153 */         else if (elements[2].contains("$"))
/* 172:    */         {
/* 173:154 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 174:155 */           this.result = this.result.concat("subi " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 175:    */         }
/* 176:    */         else
/* 177:    */         {
/* 178:158 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 179:159 */           this.result = this.result.concat("subi " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 180:    */         }
/* 181:    */       }
/* 182:162 */       else if (elements[0].equalsIgnoreCase("WRITEI"))
/* 183:    */       {
/* 184:163 */         if (elements[1].contains("$")) {
/* 185:164 */           this.result = this.result.concat("sys writei " + createTemp(elements[1]) + "\n");
/* 186:    */         } else {
/* 187:167 */           this.result = this.result.concat("sys writei " + elements[1] + "\n");
/* 188:    */         }
/* 189:    */       }
/* 190:171 */       else if (elements[0].equalsIgnoreCase("WRITES"))
/* 191:    */       {
/* 192:172 */         this.result = this.result.concat("sys writes " + elements[1] + "\n");
/* 193:    */       }
/* 194:175 */       else if (elements[0].equalsIgnoreCase("READI"))
/* 195:    */       {
/* 196:176 */         if (elements[1].contains("$")) {
/* 197:177 */           this.result = this.result.concat("sys readi " + createTemp(elements[1]) + "\n");
/* 198:    */         } else {
/* 199:180 */           this.result = this.result.concat("sys readi " + elements[1] + "\n");
/* 200:    */         }
/* 201:    */       }
/* 202:184 */       else if (elements[0].equalsIgnoreCase("STOREF"))
/* 203:    */       {
/* 204:185 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 205:    */         {
/* 206:186 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 207:    */         }
/* 208:188 */         else if (elements[1].contains("$"))
/* 209:    */         {
/* 210:189 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + elements[2] + "\n");
/* 211:    */         }
/* 212:191 */         else if (elements[2].contains("$"))
/* 213:    */         {
/* 214:192 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 215:    */         }
/* 216:    */         else
/* 217:    */         {
/* 218:195 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 219:196 */           this.result = this.result.concat("move " + createTemp(elements[2]) + " " + elements[2] + "\n");
/* 220:    */         }
/* 221:    */       }
/* 222:199 */       else if (elements[0].equalsIgnoreCase("MULTF"))
/* 223:    */       {
/* 224:200 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 225:    */         {
/* 226:201 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 227:202 */           this.result = this.result.concat("mulr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 228:    */         }
/* 229:204 */         else if (elements[1].contains("$"))
/* 230:    */         {
/* 231:205 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 232:206 */           this.result = this.result.concat("mulr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 233:    */         }
/* 234:208 */         else if (elements[2].contains("$"))
/* 235:    */         {
/* 236:209 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 237:210 */           this.result = this.result.concat("mulr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 238:    */         }
/* 239:    */         else
/* 240:    */         {
/* 241:213 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 242:214 */           this.result = this.result.concat("mulr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 243:    */         }
/* 244:    */       }
/* 245:217 */       else if (elements[0].equalsIgnoreCase("ADDF"))
/* 246:    */       {
/* 247:218 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 248:    */         {
/* 249:219 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 250:220 */           this.result = this.result.concat("addr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 251:    */         }
/* 252:222 */         else if (elements[1].contains("$"))
/* 253:    */         {
/* 254:223 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 255:224 */           this.result = this.result.concat("addr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 256:    */         }
/* 257:226 */         else if (elements[2].contains("$"))
/* 258:    */         {
/* 259:227 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 260:228 */           this.result = this.result.concat("addr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 261:    */         }
/* 262:    */         else
/* 263:    */         {
/* 264:231 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 265:232 */           this.result = this.result.concat("addr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 266:    */         }
/* 267:    */       }
/* 268:235 */       else if (elements[0].equalsIgnoreCase("DIVF"))
/* 269:    */       {
/* 270:236 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 271:    */         {
/* 272:237 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 273:238 */           this.result = this.result.concat("divr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 274:    */         }
/* 275:240 */         else if (elements[1].contains("$"))
/* 276:    */         {
/* 277:241 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 278:242 */           this.result = this.result.concat("divr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 279:    */         }
/* 280:244 */         else if (elements[2].contains("$"))
/* 281:    */         {
/* 282:245 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 283:246 */           this.result = this.result.concat("divr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 284:    */         }
/* 285:    */         else
/* 286:    */         {
/* 287:249 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 288:250 */           this.result = this.result.concat("divr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 289:    */         }
/* 290:    */       }
/* 291:253 */       else if (elements[0].equalsIgnoreCase("SUBF"))
/* 292:    */       {
/* 293:254 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 294:    */         {
/* 295:255 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 296:256 */           this.result = this.result.concat("subr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 297:    */         }
/* 298:258 */         else if (elements[1].contains("$"))
/* 299:    */         {
/* 300:259 */           this.result = this.result.concat("move " + createTemp(elements[1]) + " " + createTemp(elements[3]) + "\n");
/* 301:260 */           this.result = this.result.concat("subr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 302:    */         }
/* 303:262 */         else if (elements[2].contains("$"))
/* 304:    */         {
/* 305:263 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 306:264 */           this.result = this.result.concat("subr " + createTemp(elements[2]) + " " + createTemp(elements[3]) + "\n");
/* 307:    */         }
/* 308:    */         else
/* 309:    */         {
/* 310:267 */           this.result = this.result.concat("move " + elements[1] + " " + createTemp(elements[3]) + "\n");
/* 311:268 */           this.result = this.result.concat("subr " + elements[2] + " " + createTemp(elements[3]) + "\n");
/* 312:    */         }
/* 313:    */       }
/* 314:271 */       else if (elements[0].equalsIgnoreCase("WRITEF"))
/* 315:    */       {
/* 316:272 */         if (elements[1].contains("$")) {
/* 317:273 */           this.result = this.result.concat("sys writer " + createTemp(elements[1]) + " " + "\n");
/* 318:    */         } else {
/* 319:276 */           this.result = this.result.concat("sys writer " + elements[1] + " " + "\n");
/* 320:    */         }
/* 321:    */       }
/* 322:280 */       else if (elements[0].equalsIgnoreCase("READF"))
/* 323:    */       {
/* 324:281 */         if (elements[1].contains("$")) {
/* 325:282 */           this.result = this.result.concat("sys readr " + createTemp(elements[1]) + " " + "\n");
/* 326:    */         } else {
/* 327:285 */           this.result = this.result.concat("sys readr " + elements[1] + " " + "\n");
/* 328:    */         }
/* 329:    */       }
/* 330:288 */       else if (elements[0].equalsIgnoreCase("LABEL"))
/* 331:    */       {
/* 332:289 */         this.result = this.result.concat("label " + elements[1] + " " + "\n");
/* 333:290 */         if (!elements[1].contains("label")) {
/* 334:291 */           this.labelIndicator = elements[1];
/* 335:    */         }
/* 336:    */       }
/* 337:294 */       else if (elements[0].equalsIgnoreCase("JUMP"))
/* 338:    */       {
/* 339:295 */         this.result = this.result.concat("jmp " + elements[1] + " " + "\n");
/* 340:    */       }
/* 341:298 */       else if (elements[0].equalsIgnoreCase("LEI"))
/* 342:    */       {
/* 343:299 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 344:    */         {
/* 345:300 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 346:    */           {
/* 347:301 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 348:302 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 349:    */           }
/* 350:    */           else
/* 351:    */           {
/* 352:305 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 353:    */           }
/* 354:307 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 355:    */         }
/* 356:309 */         else if (elements[1].contains("$"))
/* 357:    */         {
/* 358:310 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 359:311 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 360:312 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 361:    */         }
/* 362:314 */         else if (elements[2].contains("$"))
/* 363:    */         {
/* 364:315 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 365:316 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 366:    */         }
/* 367:    */         else
/* 368:    */         {
/* 369:319 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 370:320 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 371:321 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 372:    */         }
/* 373:    */       }
/* 374:325 */       else if (elements[0].equalsIgnoreCase("GEI"))
/* 375:    */       {
/* 376:326 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 377:    */         {
/* 378:327 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 379:    */           {
/* 380:328 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 381:329 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 382:    */           }
/* 383:    */           else
/* 384:    */           {
/* 385:332 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 386:    */           }
/* 387:334 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 388:    */         }
/* 389:336 */         else if (elements[1].contains("$"))
/* 390:    */         {
/* 391:337 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 392:338 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 393:339 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 394:    */         }
/* 395:341 */         else if (elements[2].contains("$"))
/* 396:    */         {
/* 397:342 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 398:343 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 399:    */         }
/* 400:    */         else
/* 401:    */         {
/* 402:346 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 403:347 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 404:348 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 405:    */         }
/* 406:    */       }
/* 407:352 */       else if (elements[0].equalsIgnoreCase("NEI"))
/* 408:    */       {
/* 409:353 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 410:    */         {
/* 411:354 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 412:    */           {
/* 413:355 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 414:356 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 415:    */           }
/* 416:    */           else
/* 417:    */           {
/* 418:359 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 419:    */           }
/* 420:361 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 421:    */         }
/* 422:363 */         else if (elements[1].contains("$"))
/* 423:    */         {
/* 424:364 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 425:365 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 426:366 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 427:    */         }
/* 428:368 */         else if (elements[2].contains("$"))
/* 429:    */         {
/* 430:369 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 431:370 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 432:    */         }
/* 433:    */         else
/* 434:    */         {
/* 435:373 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 436:374 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 437:375 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 438:    */         }
/* 439:    */       }
/* 440:379 */       else if (elements[0].equalsIgnoreCase("EQI"))
/* 441:    */       {
/* 442:380 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 443:    */         {
/* 444:381 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 445:    */           {
/* 446:382 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 447:383 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 448:    */           }
/* 449:    */           else
/* 450:    */           {
/* 451:386 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 452:    */           }
/* 453:388 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 454:    */         }
/* 455:390 */         else if (elements[1].contains("$"))
/* 456:    */         {
/* 457:391 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 458:392 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 459:393 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 460:    */         }
/* 461:395 */         else if (elements[2].contains("$"))
/* 462:    */         {
/* 463:396 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 464:397 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 465:    */         }
/* 466:    */         else
/* 467:    */         {
/* 468:400 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 469:401 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 470:402 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 471:    */         }
/* 472:    */       }
/* 473:406 */       else if (elements[0].equalsIgnoreCase("GTI"))
/* 474:    */       {
/* 475:407 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 476:    */         {
/* 477:408 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 478:    */           {
/* 479:409 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 480:410 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 481:    */           }
/* 482:    */           else
/* 483:    */           {
/* 484:413 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 485:    */           }
/* 486:415 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 487:    */         }
/* 488:417 */         else if (elements[1].contains("$"))
/* 489:    */         {
/* 490:418 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 491:419 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 492:420 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 493:    */         }
/* 494:422 */         else if (elements[2].contains("$"))
/* 495:    */         {
/* 496:423 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 497:424 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 498:    */         }
/* 499:    */         else
/* 500:    */         {
/* 501:427 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 502:428 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 503:429 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 504:    */         }
/* 505:    */       }
/* 506:433 */       else if (elements[0].equalsIgnoreCase("LTI"))
/* 507:    */       {
/* 508:434 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 509:    */         {
/* 510:435 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 511:    */           {
/* 512:436 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 513:437 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 514:    */           }
/* 515:    */           else
/* 516:    */           {
/* 517:440 */             this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 518:    */           }
/* 519:442 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 520:    */         }
/* 521:444 */         else if (elements[1].contains("$"))
/* 522:    */         {
/* 523:445 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 524:446 */           this.result = this.result.concat("cmpi " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 525:447 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 526:    */         }
/* 527:449 */         else if (elements[2].contains("$"))
/* 528:    */         {
/* 529:450 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 530:451 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 531:    */         }
/* 532:    */         else
/* 533:    */         {
/* 534:454 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 535:455 */           this.result = this.result.concat("cmpi " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 536:456 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 537:    */         }
/* 538:    */       }
/* 539:460 */       else if (elements[0].equalsIgnoreCase("LEF"))
/* 540:    */       {
/* 541:461 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 542:    */         {
/* 543:462 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 544:    */           {
/* 545:463 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 546:464 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 547:    */           }
/* 548:    */           else
/* 549:    */           {
/* 550:467 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 551:    */           }
/* 552:469 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 553:    */         }
/* 554:471 */         else if (elements[1].contains("$"))
/* 555:    */         {
/* 556:472 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 557:473 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 558:474 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 559:    */         }
/* 560:476 */         else if (elements[2].contains("$"))
/* 561:    */         {
/* 562:477 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 563:478 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 564:    */         }
/* 565:    */         else
/* 566:    */         {
/* 567:481 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 568:482 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 569:483 */           this.result = this.result.concat("jle " + elements[3] + "\n");
/* 570:    */         }
/* 571:    */       }
/* 572:487 */       else if (elements[0].equalsIgnoreCase("GEF"))
/* 573:    */       {
/* 574:488 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 575:    */         {
/* 576:489 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 577:    */           {
/* 578:490 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 579:491 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 580:    */           }
/* 581:    */           else
/* 582:    */           {
/* 583:494 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 584:    */           }
/* 585:496 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 586:    */         }
/* 587:498 */         else if (elements[1].contains("$"))
/* 588:    */         {
/* 589:499 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 590:500 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 591:501 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 592:    */         }
/* 593:503 */         else if (elements[2].contains("$"))
/* 594:    */         {
/* 595:504 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 596:505 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 597:    */         }
/* 598:    */         else
/* 599:    */         {
/* 600:508 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 601:509 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 602:510 */           this.result = this.result.concat("jge " + elements[3] + "\n");
/* 603:    */         }
/* 604:    */       }
/* 605:514 */       else if (elements[0].equalsIgnoreCase("NEF"))
/* 606:    */       {
/* 607:515 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 608:    */         {
/* 609:516 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 610:    */           {
/* 611:517 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 612:518 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 613:    */           }
/* 614:    */           else
/* 615:    */           {
/* 616:521 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 617:    */           }
/* 618:523 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 619:    */         }
/* 620:525 */         else if (elements[1].contains("$"))
/* 621:    */         {
/* 622:526 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 623:527 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 624:528 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 625:    */         }
/* 626:530 */         else if (elements[2].contains("$"))
/* 627:    */         {
/* 628:531 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 629:532 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 630:    */         }
/* 631:    */         else
/* 632:    */         {
/* 633:535 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 634:536 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 635:537 */           this.result = this.result.concat("jne " + elements[3] + "\n");
/* 636:    */         }
/* 637:    */       }
/* 638:541 */       else if (elements[0].equalsIgnoreCase("EQF"))
/* 639:    */       {
/* 640:542 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 641:    */         {
/* 642:543 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 643:    */           {
/* 644:544 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 645:545 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 646:    */           }
/* 647:    */           else
/* 648:    */           {
/* 649:548 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 650:    */           }
/* 651:550 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 652:    */         }
/* 653:552 */         else if (elements[1].contains("$"))
/* 654:    */         {
/* 655:553 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 656:554 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 657:555 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 658:    */         }
/* 659:557 */         else if (elements[2].contains("$"))
/* 660:    */         {
/* 661:558 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 662:559 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 663:    */         }
/* 664:    */         else
/* 665:    */         {
/* 666:562 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 667:563 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 668:564 */           this.result = this.result.concat("jeq " + elements[3] + "\n");
/* 669:    */         }
/* 670:    */       }
/* 671:568 */       else if (elements[0].equalsIgnoreCase("GTF"))
/* 672:    */       {
/* 673:569 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 674:    */         {
/* 675:570 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 676:    */           {
/* 677:571 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 678:572 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 679:    */           }
/* 680:    */           else
/* 681:    */           {
/* 682:575 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 683:    */           }
/* 684:577 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 685:    */         }
/* 686:579 */         else if (elements[1].contains("$"))
/* 687:    */         {
/* 688:580 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 689:581 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 690:582 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 691:    */         }
/* 692:584 */         else if (elements[2].contains("$"))
/* 693:    */         {
/* 694:585 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 695:586 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 696:    */         }
/* 697:    */         else
/* 698:    */         {
/* 699:589 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 700:590 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 701:591 */           this.result = this.result.concat("jgt " + elements[3] + "\n");
/* 702:    */         }
/* 703:    */       }
/* 704:595 */       else if (elements[0].equalsIgnoreCase("LTF"))
/* 705:    */       {
/* 706:596 */         if ((elements[1].contains("$")) && (elements[2].contains("$")))
/* 707:    */         {
/* 708:597 */           if ((elements[1].contains("$P")) || (elements[1].contains("$L")) || (elements[2].contains("$P")) || (elements[2].contains("$L")))
/* 709:    */           {
/* 710:598 */             this.result = this.result.concat("move " + createTemp(elements[2]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 711:599 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(shiftToUnusedR((String)((ArrayList)this.tempMap.get(this.labelIndicator)).get(((ArrayList)this.tempMap.get(this.labelIndicator)).size() - 1))) + "\n");
/* 712:    */           }
/* 713:    */           else
/* 714:    */           {
/* 715:602 */             this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 716:    */           }
/* 717:604 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 718:    */         }
/* 719:606 */         else if (elements[1].contains("$"))
/* 720:    */         {
/* 721:607 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 722:608 */           this.result = this.result.concat("cmpr " + createTemp(elements[1]) + " " + createTemp(elements[2]) + "\n");
/* 723:609 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 724:    */         }
/* 725:611 */         else if (elements[2].contains("$"))
/* 726:    */         {
/* 727:612 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 728:613 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 729:    */         }
/* 730:    */         else
/* 731:    */         {
/* 732:616 */           this.result = this.result.concat("move " + elements[2] + " " + createTemp(elements[2]) + "\n");
/* 733:617 */           this.result = this.result.concat("cmpr " + elements[1] + " " + createTemp(elements[2]) + "\n");
/* 734:618 */           this.result = this.result.concat("jlt " + elements[3] + "\n");
/* 735:    */         }
/* 736:    */       }
/* 737:622 */       else if (elements[0].equalsIgnoreCase("jsr"))
/* 738:    */       {
/* 739:623 */         for (int k = 0; k < this.registerNumber; k++) {
/* 740:624 */           this.result = this.result.concat("push r" + Integer.toString(k) + "\n");
/* 741:    */         }
/* 742:626 */         this.result = this.result.concat("jsr " + elements[1] + "\n");
/* 743:627 */         for (int k = this.registerNumber - 1; k >= 0; k--) {
/* 744:628 */           this.result = this.result.concat("pop r" + Integer.toString(k) + "\n");
/* 745:    */         }
/* 746:    */       }
/* 747:631 */       else if (elements[0].equalsIgnoreCase("push"))
/* 748:    */       {
/* 749:632 */         if (elements.length == 1) {
/* 750:633 */           this.result = this.result.concat("push\n");
/* 751:636 */         } else if (elements[1].contains("$")) {
/* 752:637 */           this.result = this.result.concat("push " + createTemp(elements[1]) + "\n");
/* 753:    */         } else {
/* 754:640 */           this.result = this.result.concat("push " + elements[1] + "\n");
/* 755:    */         }
/* 756:    */       }
/* 757:645 */       else if (elements[0].equalsIgnoreCase("pop"))
/* 758:    */       {
/* 759:646 */         if (elements.length == 1) {
/* 760:647 */           this.result = this.result.concat("pop\n");
/* 761:650 */         } else if (elements[1].contains("$")) {
/* 762:651 */           this.result = this.result.concat("pop " + createTemp(elements[1]) + "\n");
/* 763:    */         } else {
/* 764:654 */           this.result = this.result.concat("pop " + elements[1] + "\n");
/* 765:    */         }
/* 766:    */       }
/* 767:659 */       else if (elements[0].equalsIgnoreCase("link"))
/* 768:    */       {
/* 769:660 */         this.result = this.result.concat("link " + this.linkCount.get(this.labelIndicator) + "\n");
/* 770:    */       }
/* 771:663 */       else if (elements[0].equalsIgnoreCase("RET"))
/* 772:    */       {
/* 773:664 */         this.result = this.result.concat("unlnk\n");
/* 774:665 */         this.result = this.result.concat("ret\n");
/* 775:    */       }
/* 776:    */     }
/* 777:669 */     this.result = this.result.concat("end");
/* 778:670 */     return this.result;
/* 779:    */   }
/* 780:    */   
/* 781:    */   private String shiftToUnusedR(String input)
/* 782:    */   {
/* 783:674 */     return "$T" + Integer.toString(Integer.parseInt(input.substring(2)) + 1);
/* 784:    */   }
/* 785:    */   
/* 786:    */   public void initailMain()
/* 787:    */   {
/* 788:678 */     this.result = this.result.concat("push\n");
/* 789:679 */     for (int k = 0; k < this.registerNumber; k++) {
/* 790:680 */       this.result = this.result.concat("push r" + Integer.toString(k) + "\n");
/* 791:    */     }
/* 792:682 */     this.result = this.result.concat("jsr main\n");
/* 793:683 */     this.result = this.result.concat("sys halt\n");
/* 794:    */   }
/* 795:    */   
/* 796:    */   public void IRcodeComment()
/* 797:    */   {
/* 798:687 */     for (int i = 0; i < this.IR.size(); i++) {
/* 799:688 */       this.result = this.result.concat(";" + (String)this.IR.get(i) + "\n");
/* 800:    */     }
/* 801:    */   }
/* 802:    */   
/* 803:    */   public void initialGlobal()
/* 804:    */   {
/* 805:694 */     for (Scope scope : this.table.scopeStack.subList(0, this.table.scopeStack.size())) {
/* 806:695 */       if (scope.type.equalsIgnoreCase("GLOBAL")) {
/* 807:696 */         for (String key : scope.symbolMap.keySet()) {
/* 808:697 */           if (((Symbol)scope.symbolMap.get(key)).type == ValueType.INT) {
/* 809:698 */             this.result = this.result.concat("var " + key + "\n");
/* 810:700 */           } else if (((Symbol)scope.symbolMap.get(key)).type == ValueType.FLOAT) {
/* 811:701 */             this.result = this.result.concat("var " + key + "\n");
/* 812:703 */           } else if (((Symbol)scope.symbolMap.get(key)).type == ValueType.STRING) {
/* 813:705 */             this.result = this.result.concat("str " + key + " " + ((Symbol)scope.symbolMap.get(key)).descriptor.content + "\n");
/* 814:    */           } else {
/* 815:708 */             System.out.println("error@initialGlobal");
/* 816:    */           }
/* 817:    */         }
/* 818:    */       }
/* 819:    */     }
/* 820:    */   }
/* 821:    */   
/* 822:    */   public String createTemp(String temp)
/* 823:    */   {
/* 824:716 */     if (((Map)this.TR.get(this.labelIndicator)).containsKey(temp)) {
/* 825:717 */       return (String)((Map)this.TR.get(this.labelIndicator)).get(temp);
/* 826:    */     }
/* 827:720 */     System.out.println("register not enough!! " + temp);
/* 828:    */     
/* 829:722 */     return null;
/* 830:    */   }
/* 831:    */ }


/* Location:           C:\Users\Adam\Downloads\step6.jar
 * Qualified Name:     IRToTiny
 * JD-Core Version:    0.7.0.1
 */