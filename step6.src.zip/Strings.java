/*  1:   */ import java.util.ArrayList;
/*  2:   */ 
/*  3:   */ class Strings
/*  4:   */ {
/*  5:   */   public static String asString(ArrayList<String> parameters, boolean iden, String separater)
/*  6:   */   {
/*  7:16 */     return "";
/*  8:   */   }
/*  9:   */ }


/* Location:           C:\Users\Adam\Downloads\step6.jar
 * Qualified Name:     Strings
 * JD-Core Version:    0.7.0.1
 */